package com.example.prayer

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private var offset = 0
    private lateinit var dateTv: TextView
    private lateinit var nextTv: TextView
    private lateinit var locTv: TextView
    private val rows = ArrayList<TextView>()
    private val handler = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("hh:mm a", Locale("ar", "EG"))

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 30000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 64, 40, 32)
        }

        nextTv = TextView(this).apply {
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        root.addView(nextTv)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val prev = Button(this).apply { text = "▶"; setOnClickListener { offset--; refresh() } }
        val nxt = Button(this).apply { text = "◀"; setOnClickListener { offset++; refresh() } }
        dateTv = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setOnClickListener { offset = 0; refresh() }
        }
        nav.addView(prev)
        nav.addView(dateTv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        nav.addView(nxt)
        root.addView(nav)

        for (i in 0..4) {
            val tv = TextView(this).apply {
                textSize = 24f
                setPadding(0, 20, 0, 20)
            }
            rows.add(tv)
            root.addView(tv)
        }

        locTv = TextView(this).apply { textSize = 13f; setPadding(0, 24, 0, 8) }
        root.addView(locTv)

        root.addView(Button(this).apply {
            text = "تحديد موقعي (لدقة أعلى)"
            setOnClickListener {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 7)
            }
        })

        root.addView(Switch(this).apply {
            text = "تفعيل منبّه الصلاة"
            isChecked = Scheduler.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                Scheduler.setEnabled(this@MainActivity, checked)
                Scheduler.schedule(this@MainActivity)
                refresh()
            }
        })

        root.addView(Button(this).apply {
            text = "تجربة التنبيه الآن"
            setOnClickListener {
                Scheduler.notifyPrayer(this@MainActivity, Scheduler.next(this@MainActivity, System.currentTimeMillis()).first)
            }
        })

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 8)
        }
        Scheduler.ensureChannel(this)
        Scheduler.schedule(this)
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun refresh() {
        val lat = Scheduler.lat(this)
        val lon = Scheduler.lon(this)
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, offset) }
        val t = PrayerCalc.forDay(cal, lat, lon)
        dateTv.text = SimpleDateFormat("EEEE d MMMM yyyy", Locale("ar", "EG")).format(cal.time)

        val now = System.currentTimeMillis()
        val (ni, nt) = Scheduler.next(this, now)
        for (i in 0..4) {
            val mark = if (offset == 0 && t[i] == nt) "◀ " else "    "
            rows[i].text = mark + PrayerCalc.NAMES[i] + ":   " + fmt.format(Date(t[i]))
            rows[i].setTypeface(null, if (offset == 0 && t[i] == nt) Typeface.BOLD else Typeface.NORMAL)
        }

        val mins = ((nt - now) / 60000).toInt()
        nextTv.text = "الصلاة القادمة: ${PrayerCalc.NAMES[ni]} الساعة ${fmt.format(Date(nt))}\n" +
            "باقي ${mins / 60} ساعة و ${mins % 60} دقيقة" +
            if (Scheduler.enabled(this)) "" else "\n(المنبّه متوقف)"

        locTv.text = if (Scheduler.isCustomLocation(this))
            String.format(Locale.US, "الموقع: %.3f , %.3f", lat, lon)
        else "الموقع: القاهرة (افتراضي)"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            fetchLocation()
        }
    }

    private fun fetchLocation() {
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best.time) best = l
            }
            if (best == null) {
                Toast.makeText(this, "تعذّر تحديد الموقع. افتح خرائط جوجل مرة ثم أعد المحاولة.", Toast.LENGTH_LONG).show()
                return
            }
            Scheduler.setLocation(this, best.latitude, best.longitude)
            Scheduler.schedule(this)
            refresh()
        } catch (e: SecurityException) {
            Toast.makeText(this, "لا يوجد إذن للموقع.", Toast.LENGTH_SHORT).show()
        }
    }
}
