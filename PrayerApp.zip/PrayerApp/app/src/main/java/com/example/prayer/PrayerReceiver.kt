package com.example.prayer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PrayerReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Scheduler.ACTION_FIRE) {
            val idx = intent.getIntExtra("idx", -1)
            if (idx in 0..4 && Scheduler.enabled(ctx)) Scheduler.notifyPrayer(ctx, idx)
        }
        // بعد كل رنين أو إقلاع أو تغيير وقت/منطقة: جدول الصلاة التالية
        Scheduler.schedule(ctx)
    }
}
