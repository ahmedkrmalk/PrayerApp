package com.example.prayer

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import java.util.Calendar

object Scheduler {
    const val ACTION_FIRE = "com.example.prayer.FIRE"
    private const val CHANNEL = "adhan_alarm"

    // القاهرة كموقع افتراضي
    private const val DEF_LAT = "30.0444"
    private const val DEF_LON = "31.2357"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("prayer", Context.MODE_PRIVATE)

    fun lat(ctx: Context) = (prefs(ctx).getString("lat", DEF_LAT) ?: DEF_LAT).toDouble()
    fun lon(ctx: Context) = (prefs(ctx).getString("lon", DEF_LON) ?: DEF_LON).toDouble()
    fun isCustomLocation(ctx: Context) = prefs(ctx).contains("lat")
    fun enabled(ctx: Context) = prefs(ctx).getBoolean("enabled", true)

    fun setEnabled(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("enabled", v).apply()
    fun setLocation(ctx: Context, lat: Double, lon: Double) =
        prefs(ctx).edit().putString("lat", lat.toString()).putString("lon", lon.toString()).apply()

    /** أقرب صلاة بعد الوقت المعطى: (رقم الصلاة، وقتها) */
    fun next(ctx: Context, from: Long): Pair<Int, Long> {
        val base = Calendar.getInstance().apply { timeInMillis = from }
        for (off in 0..2) {
            val c = (base.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, off) }
            val t = PrayerCalc.forDay(c, lat(ctx), lon(ctx))
            for (i in 0..4) if (t[i] > from) return Pair(i, t[i])
        }
        return Pair(0, from + 3600000L)
    }

    private fun firePending(ctx: Context, idx: Int): PendingIntent {
        val i = Intent(ctx, PrayerReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra("idx", idx)
        return PendingIntent.getBroadcast(
            ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun openAppPending(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 2, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** يجدول منبّه الصلاة القادمة فقط؛ وبعد رنينه يجدول التي بعدها (سلسلة لا تنتهي). */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!enabled(ctx)) {
            am.cancel(firePending(ctx, 0))
            return
        }
        val (idx, time) = next(ctx, System.currentTimeMillis())
        // setAlarmClock: دقيق، يعمل في Doze، ولا يحتاج إذن خاص
        am.setAlarmClock(AlarmManager.AlarmClockInfo(time, openAppPending(ctx)), firePending(ctx, idx))
    }

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val ch = NotificationChannel(CHANNEL, "مواقيت الصلاة", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        ch.enableVibration(true)
        ch.vibrationPattern = longArrayOf(0, 500, 300, 500)
        nm.createNotificationChannel(ch)
    }

    fun notifyPrayer(ctx: Context, idx: Int) {
        ensureChannel(ctx)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("حان الآن وقت صلاة ${PrayerCalc.NAMES[idx]}")
            .setContentText("حيّ على الصلاة")
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppPending(ctx))
            .build()
        nm.notify(100 + idx, n)
    }
}
