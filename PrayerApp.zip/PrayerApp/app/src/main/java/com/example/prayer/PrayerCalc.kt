package com.example.prayer

import java.util.Calendar
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/**
 * حساب مواقيت الصلاة فلكياً (بدون إنترنت) بطريقة الهيئة المصرية العامة للمساحة:
 * الفجر 19.5° والعشاء 17.5°، العصر بالمذهب الجمهور (ظل = 1).
 * يصلح لأي تاريخ في المستقبل.
 */
object PrayerCalc {
    val NAMES = arrayOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

    private fun rad(d: Double) = d * PI / 180.0
    private fun deg(r: Double) = r * 180.0 / PI
    private fun dsin(d: Double) = sin(rad(d))
    private fun dcos(d: Double) = cos(rad(d))
    private fun dtan(d: Double) = tan(rad(d))
    private fun darcsin(x: Double) = deg(asin(x))
    private fun darccos(x: Double) = deg(acos(x.coerceIn(-1.0, 1.0)))
    private fun darctan2(y: Double, x: Double) = deg(atan2(y, x))
    private fun darccot(x: Double) = deg(atan(1.0 / x))
    private fun fix(a: Double, b: Double): Double = a - b * floor(a / b)

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** المواقيت بالساعات (توقيت محلي) : فجر، ظهر، عصر، مغرب، عشاء */
    fun hours(year: Int, month: Int, day: Int, lat: Double, lng: Double, tz: Double): DoubleArray {
        val jd = julian(year, month, day) - lng / (15.0 * 24.0)

        fun sun(t: Double): DoubleArray {
            val d = jd + t - 2451545.0
            val g = fix(357.529 + 0.98560028 * d, 360.0)
            val q = fix(280.459 + 0.98564736 * d, 360.0)
            val l = fix(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g), 360.0)
            val e = 23.439 - 0.00000036 * d
            val ra = fix(darctan2(dcos(e) * dsin(l), dcos(l)) / 15.0, 24.0)
            return doubleArrayOf(darcsin(dsin(e) * dsin(l)), q / 15.0 - ra)
        }

        fun mid(t: Double) = fix(12.0 - sun(t)[1], 24.0)

        fun angle(a: Double, t: Double, ccw: Boolean): Double {
            val dc = sun(t)[0]
            val x = (-dsin(a) - dsin(dc) * dsin(lat)) / (dcos(dc) * dcos(lat))
            val v = darccos(x) / 15.0
            return mid(t) + if (ccw) -v else v
        }

        fun asr(t: Double): Double {
            val dc = sun(t)[0]
            val a = -darccot(1.0 + dtan(abs(lat - dc)))
            return angle(a, t, false)
        }

        var tf = 5 / 24.0
        var td = 12 / 24.0
        var ta = 13 / 24.0
        var ts = 18 / 24.0
        var ti = 18 / 24.0
        val r = DoubleArray(5)
        repeat(2) {
            r[0] = angle(19.5, tf, true)
            r[1] = mid(td)
            r[2] = asr(ta)
            r[3] = angle(0.833, ts, false)
            r[4] = angle(17.5, ti, false)
            tf = r[0] / 24; td = r[1] / 24; ta = r[2] / 24; ts = r[3] / 24; ti = r[4] / 24
        }
        val shift = tz - lng / 15.0
        return DoubleArray(5) { r[it] + shift }
    }

    /** مواقيت يوم معيّن كـ epoch millis (يراعي التوقيت الصيفي في الجهاز). */
    fun forDay(day: Calendar, lat: Double, lng: Double): LongArray {
        val y = day.get(Calendar.YEAR)
        val m = day.get(Calendar.MONTH)
        val d = day.get(Calendar.DAY_OF_MONTH)
        val noon = Calendar.getInstance().apply { set(y, m, d, 12, 0, 0) }
        val tz = noon.timeZone.getOffset(noon.timeInMillis) / 3600000.0
        val h = hours(y, m + 1, d, lat, lng, tz)
        return LongArray(5) {
            val total = Math.round(h[it] * 60).toInt()
            Calendar.getInstance().apply {
                set(y, m, d, total / 60, total % 60, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
        }
    }
}
